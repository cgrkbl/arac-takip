import json
import base64
import io

def handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        tarih = body.get("tarih", "")
        kat_veriler = body.get("katVeriler", {})

        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        kategoriler = ["İplik", "Kumaş", "Konfeksiyon", "Mamül Sevkiyat", "Bobin Boya", "Diğer"]
        col_count = len(kategoriler)
        start_col = 2
        start_row = 2
        max_veri = max([len(v) for v in kat_veriler.values()] + [10])

        wb = Workbook()
        ws = wb.active
        ws.title = "Araç Programı"

        thin = Side(style='thin', color='000000')
        thick = Side(style='medium', color='000000')
        no = Side(style=None)

        end_col = start_col + col_count - 1
        end_row = start_row + 1 + max_veri

        def cb(r, c):
            return Border(
                left=thick if c==start_col else thin,
                right=thick if c==end_col else thin,
                top=thick if r==start_row else thin,
                bottom=thick if r==end_row else thin
            )

        for c in range(start_col, end_col+1):
            cell = ws.cell(row=start_row, column=c)
            cell.value = tarih + " ARAÇ PROGRAMI" if c==start_col else ""
            cell.font = Font(name='Arial', bold=True, size=16)
            cell.fill = PatternFill('solid', fgColor='FFD700')
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = Border(
                left=thick if c==start_col else no,
                right=thick if c==end_col else no,
                top=thick, bottom=thin
            )
        ws.merge_cells(start_row=start_row, start_column=start_col, end_row=start_row, end_column=end_col)
        ws.row_dimensions[start_row].height = 36

        for i, kat in enumerate(kategoriler):
            c = start_col + i
            cell = ws.cell(row=start_row+1, column=c)
            cell.value = kat
            cell.font = Font(name='Arial', bold=True, size=12)
            cell.fill = PatternFill('solid', fgColor='00CFCF')
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = cb(start_row+1, c)
        ws.row_dimensions[start_row+1].height = 26

        for r in range(start_row+2, end_row+1):
            ws.row_dimensions[r].height = 20
            for i, kat in enumerate(kategoriler):
                c = start_col + i
                cell = ws.cell(row=r, column=c)
                idx = r - (start_row+2)
                deger = kat_veriler.get(kat, [])
                cell.value = deger[idx] if idx < len(deger) else ""
                cell.font = Font(name='Arial', size=11)
                cell.alignment = Alignment(horizontal='left', vertical='center')
                cell.border = cb(r, c)

        ws.column_dimensions['A'].width = 4
        for i in range(col_count):
            ws.column_dimensions[get_column_letter(start_col+i)].width = 24
        ws.row_dimensions[1].height = 12

        buf = io.BytesIO()
        wb.save(buf)
        b64 = base64.b64encode(buf.getvalue()).decode()

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"excel": b64})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
